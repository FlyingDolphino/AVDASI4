%% Run Design Set
% This file (RunDesignSet) illustrates how to calculate mission parameters (mass, fuel and
% range) for a set of design missions defined by a target payload, target range and aircraft parameters.
% The climb performance parameters are also calculated.
% 
% The main file for running the Design Case is *FindDesignPoint*
% For brief description type: _help FindDesignPoint_
% 
% Created by: D Rezgui and S Mitchell
% Copyright: University of Bristol

%% Initialise aircraft parameters
% delete Par; clear Par
clear; clc
disp(' ')
disp('        ******** Aircraft Performance Tool ********');
disp('        ******** Run Design Mission Case ********')
disp(['                  ', datestr(clock)]);
disp(' ')

% Read Aircraft data from a re-defined file, e.g. 'AC_B777_AJenk'or 'AC_150C_twin'
ParFunc = 'AC_B777_AJenk'; % or ParFunc = 'AC_150C_twin';
Par     = eval(ParFunc);  % Set parameters in the "Par" object, 
                          % Default values are set in the ParFunc

disp(['... Aircraft parameters are set, based on ', ParFunc, ' data file'])
disp(' ')

% Reset parameters from default values (other parameters can be changed in
% the Par object)         
Par.PL_req    = 29050; % Required payload mass [kg]
Par.Range_req =  4779; % Required design range [nm]

% You can also reset the following parameters. (you can also change these parameters in the ParFunc file)
% Par.S                      = 376.4;     % Wing area [m^2]
% Par.PLmax                  = 45000;     % Max payload [kg]
% Par.MFC                    = 80000;     % Max Fuel capacity [kg]
% Par.MTOM                   = 230000;    % Max Take Off Mass [kg]
% Par.Airframe               = 130000;    % Operating Mass Empty [kg]
% Par.Alt_Cruise    		 = 35000;     % Cruise Alt [ft]
% Par.DragRise  	  		 = 0;     % Flag to switch drag rise in the drag polar: 1 = Yes, 0 = No

% Reset engine data parameters (if needed)
Par.interp_method = 'linear'; % or 'spline' - 'spline' is slower but allows to extrapolate data 
Par.M_ext = []; % Extend Mach number range to M_ext - change to something like 0.1 if needed 

%% Calculate the mass, fuel and range for a set of missions
% Find mission properties for a set of Mach numbers

% Define a set of cruise numbers
par_set = 0.78:0.01:0.84; % Define an appropriate parameter range
xlab = 'Mach Number [-]'; % Define a label for the parameter used for the parameter set

% Find results for the first design point (i=1)
i = 1;
disp(['Start calculations for design point number: ' num2str(i)  ' value: ' num2str(par_set(i))]);
% Set target design range. All other parameters are unchanged
Par.Mach_Cruise = par_set(i);     % Required design range [nm].
% call function FindDesignPoint to calculate mission properties
dp1(i) = FindDesignPoint(Par);
    
% Start loop for the rest of the design points
if length(par_set)>1
	for i=2:length(par_set)
		disp(['Start calculations for design point number: ' num2str(i)  ' value: ' num2str(par_set(i))]);
		% Set target design range. All other parameters are unchanged
		Par.Mach_Cruise = par_set(i);     % Required design range [nm].
		% call function FindDesignPoint to calculate mission properties
		dp1(i) = FindDesignPoint(Par, dp1(1).EngineData, dp1(1).TOM_design);
	end
else
    disp(' ');
    warning(' ... There is only one design point in this parameter set');
    disp(' ');
end

%% Plot Mission Profile
% Call plotter Design Set
PlotDSet(dp1,par_set,xlab)
drawnow
%% Repeat Design Set calculations but with drag rise corrections
% Calculate the mass, fuel and range for a set of missions
% Find mission properties for a set of Mack numbers

Par.DragRise = 1;     % Flag to switch drag rise in the drag polar: 1 = Yes, 0 = No

% Find results for the first design point (i=1)
i = 1;
disp(['Start calculations for design point number: ' num2str(i)  ' value: ' num2str(par_set(i))]);
% Set target design range. All other parameters are unchanged
Par.Mach_Cruise = par_set(i);     % Required design range [nm].
% call function FindDesignPoint to calculate mission properties
dp2(i) = FindDesignPoint(Par);
    
% Start loop for the rest of the design points
if length(par_set)>1
	for i=2:length(par_set)
		disp(['Start calculations for design point number: ' num2str(i)  ' value: ' num2str(par_set(i))]);
		% Set target design range. All other parameters are unchanged
		Par.Mach_Cruise = par_set(i);     % Required design range [nm].
		% call function FindDesignPoint to calculate mission properties
		dp2(i) = FindDesignPoint(Par, dp2(1).EngineData, dp2(1).TOM_design);
	end
else
    disp(' ');
    warning(' ... There is only one design point in this parameter set');
    disp(' ');
end

%% Plot Mission Profile
% Call plotter Design Set
PlotDSet(dp2,par_set,xlab)

%% Save results
savefile = 'DSet1.mat';
save(savefile, 'dp1', 'dp2', 'par_set','xlab');

%% Load saved data to workspace
delete Par; 
clear % clear workspace
load 'DSet1.mat';
whos % show available variables in the workspace

