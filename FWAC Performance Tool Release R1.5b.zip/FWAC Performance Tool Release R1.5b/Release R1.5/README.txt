#      FW AIRCRAFT PERFORMANCE TOOL IN MATLAB (Release 1.5, 2019)

#### INTRODUCTION
The Fixed Wing Performance Tool is an In-house MATLAB tool created by 
Rezgui, Mitchell and Gibbons at UoB 2016/2017.
For more information, email:
Djamel.Rezgui@bristol.ac.uk or n.a.mitchell@bristol.ac.uk

The equations used in this code are based largely on the reference aircraft 
in Chapter 10 of Civil Aircraft Design by Jenkinson, Simpkin & Rhodes, with 
a few modification from the Airbus design guides (AVDASI4).

To tool generates the aircraft Payload-Range Diagram and calculate the 
operational performance for:
    - given aircraft parameters (configuration, e.g. wing span, engine data, 
    MTOM, empty mass, drag polar, �)
    - target/given aircraft mission (Mach number, altitude, required range, 
    payload, �) 

The tool allows flexibility to customise the run files and plotting functions
Quick start guide available in the form of html and pdf demo files. See 
'Help' subdirectory

#### INSTALLATION
No formal installation is needed but you need to add the main folder 
'Release R#.#' and all its subdirectories to the MATLAB path.

To insure all files run smoothly, Use MATALB R2015 or higher. For lower 
versions, some plotting functions might not work. Other alternative are/will 
be provided.

For a quick start, run the files (RunDesignCase, RunDesignSet and 
RunPayloadRange) in the 'Run Folder'.

The main functions of the code are: 
    - FindDesignPoint
    - FindPayloadRangeDiag




