%
% Created by: *D Rezgui*, *S Mitchell* and *M Gibbons*, 
% University of Bristol 2017

classdef payloadrange
    %payloadrange
    
    properties
        Payload_p
        Range_p
        PLmax
        Range_PLmax
        Payload_MTOM
        Range_MTOM
        Payload_MFC
        Range_MFC
        Range_max
        dp % Design point
        Par
        EngineData
    end
    
    methods
    end
    
end

