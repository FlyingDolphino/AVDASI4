%
% Created by: *D Rezgui*, *S Mitchell* and *M Gibbons*, 
% University of Bristol 2017

classdef designpoint
    % designpoint class
    
    properties
        PL_req
        Range_req
        Par
        EngineData
        Mission
        Block
        TotalFuel
        ReserveFuel
        TOM_design
    end
    
    methods
    end
    
end

